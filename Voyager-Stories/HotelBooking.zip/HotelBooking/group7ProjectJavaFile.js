//JS for Home

